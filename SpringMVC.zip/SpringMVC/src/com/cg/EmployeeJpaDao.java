package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component(value = "jpadao")
public class EmployeeJpaDao implements Idao {
	
	@PersistenceContext
	 private EntityManager entityManager;

	@Transactional
	@Override
	public void saveEmployee(Employee e) {
		// TODO Auto-generated method stub
		System.out.println("Inside EmployeeJPADAO");
		entityManager.persist(e);
		entityManager.flush();
	}

	@Override
	public void modifyEmployee(Employee e) {
		// TODO Auto-generated method stub

	}

}
