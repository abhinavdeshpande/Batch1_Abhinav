package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component(value="dao")
public class EmployeeDao implements Idao {

	@Autowired
	private JdbcTemplate template;
	
	@Override
	public void saveEmployee(Employee e) {
		String sql = "insert into employee(id,fname,lname) values(?,?,?)";
        template.update(sql,e.getId(),e.getFname(),e.getLname());		

	}

	@Override
	public void modifyEmployee(Employee e) {
		// TODO Auto-generated method stub
	}
    
}
