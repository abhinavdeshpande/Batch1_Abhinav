package com.cg;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Employee {

	private int id;
	private String fname;
	
	@Size(min=3, max=4)
	@NotEmpty
	private String lname;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String fname, String lname) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", fname=" + fname + ", lname=" + lname + "]";
	}

}
