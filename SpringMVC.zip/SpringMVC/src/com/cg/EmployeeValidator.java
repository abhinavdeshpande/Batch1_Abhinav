package com.cg;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class EmployeeValidator implements Validator {

	@Override
	public void validate(Object target, Errors errors) {
		System.out.println("inside validate() method");
		Employee emp = (Employee) target;

		ValidationUtils.rejectIfEmpty(errors, "fname", "fname.error");
	}

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

}
