package com.cg;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/hello")
public class WelcomeController {
	@RequestMapping(method = RequestMethod.GET, value = "/abc.htm")
	public String sayWelcome1() {
		System.out.println("inside sayWelcome1() method");
		System.out.println("invoking sevice/bussiness layer 1");
		return "hello";
	}

	@RequestMapping(method = RequestMethod.GET, value = { "/pqr.htm" })
	public String sayWelcome2(Model model) {
		// URL = /hello/pqr.htm
		System.out.println("inside sayWelcome2()");
		System.out.println("invoking service layer 2");
		String msg = "Spring MVC using Annotations using Model";
		model.addAttribute("msg", msg);
		return "hello";
	}

	@RequestMapping(method = RequestMethod.GET, value = { "/xyz.htm" })
	public String sayWelcome3(Map<String, String> map) {
		// URL = /hello/xyz.htm
		System.out.println("inside sayWelcome3()");
		System.out.println("invoking service layer 3");
		String msg = "Spring MVC using Annotations using Map";
		map.put("msg", msg);
		return "hello";
	}
}