package com.cg;

public interface Idao {

	void saveEmployee(Employee e);
	void modifyEmployee(Employee e);
}
