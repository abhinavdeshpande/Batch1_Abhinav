package com.cg;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

@Controller
public class EmployeeController {
	
	@Autowired
	private Iservice service;
	
	@RequestMapping(value="/saveemp.htm",method=RequestMethod.GET)
    public String showEmpForm(Map<String,Employee> map)
    {
        System.out.println("inside showEmpForm()");
        map.put("emp", new Employee());
        return "empForm";
    }
	
	
	@RequestMapping(method=RequestMethod.POST,value="/save.htm")
//	public String saveEmployee(@RequestParam("empid") int id, String fname, String lname,Map map)
//	{
	//public String saveEmployee(@ModelAttribute("emp") Employee e,Map map)
	//{	
	public String saveEmployee(@Valid @ModelAttribute("emp") Employee e, BindingResult result,Map map) { 
		    System.out.println("inside saveEmployee() of EmployeeController");
		    map.put("emp", e);  
		    List<Employee> list = new ArrayList<>();
			list.add(e);
			
			
			//validation
			EmployeeValidator empval = new EmployeeValidator();
			//binding result :-whatever is passed to it 
			empval.validate(e, result);
			 if(result.hasErrors()) {
			      System.out.println("validation errors");
			      //return logical view      
			      return "empForm";
			 }
			 
		    service.saveEmployees(list);
		        System.out.println(e);
		          
//	    System.out.println("inside saveEmployee() of EmployeeController");
//	    System.out.println("id :" + id);
//	    System.out.println("fname :" + fname);
//	    System.out.println("lname :" + lname);
//	           
	    return "savedetails";   
	}
	
	@RequestMapping(value="/changeLocale.htm",method=RequestMethod.GET)
    public String changeLocale(@RequestParam String lang,HttpServletRequest req,Model model)
    {
        System.out.println("inside changeLocale()" + lang);
       
        HttpSession session =  req.getSession();   
        session.setAttribute(
                SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, new Locale(lang));
       
        model.addAttribute("emp", new Employee());
       
        return "redirect:saveemp.htm";
    }
}