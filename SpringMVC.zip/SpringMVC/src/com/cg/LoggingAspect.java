package com.cg;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {
	
	@Pointcut("execution(* *.save*(..))")
	public void dummy()
	{
		
	}
	
	@Before(value = "dummy()")
	public void logBefore(JoinPoint jp)
	{
		System.out.println("inside method " + jp.getSignature().getName());   // + "with args as "+Arrays.toString(joinpoint.getArgs()));

	}
	
	@AfterReturning(value="dummy()",returning="r" )
	public void logAfter(JoinPoint jp,Object r)
	{
		System.out.println("Exiting from " + jp.getSignature().getName());//                   + "with args as "+Arrays.toString(joinpoint.getArgs()));

	}
	
	@AfterThrowing(value="execution(* *.save*(..)) || execution(* *.divide(..))",throwing="e")
	public void logAfterThrows(Exception e)
	{
		System.out.println("divide by zero..not allowed." + e);

	}
	
	@Around(value="dummy()")
	public Object logAround(ProceedingJoinPoint joinpoint)
	{
		Object returnValue = null;
		System.out.println("in Around -> before");
		try {
			returnValue = joinpoint.proceed();
			System.out.println("in Around -> after");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			System.out.println("in Around afterException");
			e.printStackTrace();
		}
		return returnValue;

	}

}
