package com.cg;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component(value="service")
public class EmployeeService implements Iservice {

	@Autowired
	private Idao dao;
	
	@Override
	public void saveEmployees(List<Employee> list) {
		for (Employee e : list) {
			dao.saveEmployee(e);
		}
	}

	@Override
	public void modifyEmployees(List<Employee> list) {
		// TODO Auto-generated method stub

	}
	
	

}
